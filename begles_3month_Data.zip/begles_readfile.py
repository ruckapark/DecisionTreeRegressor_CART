# -*- coding: utf-8 -*-
"""
Created on Wed May 15 17:08:57 2019

Change path in line 21 to the path of the data files !

Begles DATA READ
Assume only one xls file in the directory

@author: gruck
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression

#locate file
path = r'C:\Users\gruck\Documents\Begles' #à modifier (r makes it a raw string)
os.chdir(path)
file = [ x for x in os.listdir() if 'xls' in x ]
#%%
#read file begles without temperature and format

df = pd.read_excel(file[0],sheet_name = 'HOTEL DE VILLE_Pts_10')
df.rename(columns = {list(df)[0] : 'datetime'},inplace = True)

#read second file with temperature data
df_temp = pd.read_csv(r'donnees_temp_bordeaux_2018.csv',sep = ';')
df_temp['Date'] =  pd.to_datetime(df_temp['Date'], format='%d/%m/%Y %H:%M')
df_temp.sort_values(by=['Date'],inplace = True)
df_temp.rename(columns = {'Date' : 'datetime'},inplace = True)

df_original = df.set_index('datetime')
#%%

#join the two arrays
df = df.merge(df_temp, how='left', left_on='datetime', right_on='datetime')
df['Temperature'].interpolate(inplace = True)
df.dropna(inplace = True)


#%% plot four subplots to have an idea of the data

#add column for weekday
df['weekday'] = df['datetime'].dt.dayofweek
df['heure'] = df['datetime'].dt.hour
df['heure minutes'] = df['datetime'].dt.strftime('%H:%M')

df.set_index('datetime', inplace = True)

#minutes en decimal de l'heure (fraction of an hour)
df['hm'] = df['heure minutes'].apply(lambda x: int(100*int(x.split(':')[0])+(5/3)*int(x.split(':')[1])))

df.to_csv(r'begles_3month_Data.csv',sep = ';')

#%% plots

fig_sig,ax_sig = plt.subplots(2,2) 
plt.suptitle('Data for September to December in 2018')

ax_sig[0,0].plot(df_original)
ax_sig[0,0].set_title('Power over 3 months')
ax_sig[0,0].xaxis.set_major_locator(plt.LinearLocator(4))

ax_sig[0,1].plot(df.groupby('heure minutes').mean()['PS ATTEINTE'])
ax_sig[0,1].set_title('Mean power throughout 24 hour day')
ax_sig[0,1].xaxis.set_major_locator(plt.LinearLocator(9))

ax_sig[1,0].plot(df.groupby('weekday').mean()['PS ATTEINTE'])
ax_sig[1,0].set_title('Average Power for Day of the Week')

ax_sig[1,1].scatter(df['Temperature'],df['PS ATTEINTE'])
ax_sig[1,1].set_title('Scatter plot for Temperature vs. Power Output')

#tight layout
fig_sig.tight_layout(rect = [0, 0.03, 1, 0.95])

#fig_sig.savefig('firstPlots.png')